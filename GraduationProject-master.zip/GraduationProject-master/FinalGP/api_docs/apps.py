from django.apps import AppConfig


class ApiDocsConfig(AppConfig):
    name = 'api_docs'

#Print HI