1 - INSTALL ANACODA 
2 - CREATE PYTHON ENV ON PY 3.6 
3 - RUN THE FOLLOWING SCRIPTS IN ORDER:	
	A.   activate <ANACONDA ENV NAME>
	B.   pip install tensorflow
	C.   pip install tensorflow-GPU
	D.   pip install tensorflow-addons
	E.   pip install tensorflow-hub
	F.   pip install tensorflow-datasets
	G.  pip install matplotlib
	H.  pip install scikit-image
	J.   pip install opencv-python

4 - All the code leads to main
 