import "regenerator-runtime/runtime";
import App from './components/index';